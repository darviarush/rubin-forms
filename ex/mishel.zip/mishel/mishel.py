#!/usr/bin/env python
#-*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')

import xmpp, atexit, json, codecs
import os.path
import schedule

save_path = 'mishel.json'
xmpp_jid = 'mishel@jabber.ru'
xmpp_pwd = 'detiOkeana12'

to = 'halfdroy@gmail.com'
#msg = 'Привет!'
jabber = None


class Mishel:
	""" Мишель """

	def __init__(self):
		''' конструктор '''
		
		""" загружает данные """
		if os.path.isfile(save_path):
			with codecs.open(save_path, "rb", encoding='utf8') as f:
				self.ion = json.load(f)
		else:
			self.ion = {
				tz: [],		# задания
				idx: 0,		# номер задания
			}
		self

	def save(self):
		''' выполняется при завершении и сохраняет данные '''
		with codecs.open(save_path, "wb", encoding='utf8') as f:
			json.dump(f, ion)
		self
			
	def message(self, msg):
		''' пришло сообщение '''
		#print 'message_callback', msg.getType(), msg.getID(), msg.getFrom(), msg.getThread(), msg.getSubject(), msg.getBody(), repr(msg.getProperties())
		
		s = msg.getBody()
		id = msg.getFrom()
		
		if s:
			jabber.send(xmpp.protocol.Message(id, u"вау! приветики! ты сказал: %s" % s))
			
		self
		
	

	
mishel = Mishel()

jid = xmpp.protocol.JID(xmpp_jid)
jabber = xmpp.Client(jid.getDomain(),debug=[])
jabber.connect(secure=0)
jabber.auth(jid.getNode(),str(xmpp_pwd),resource='xmpppy')

''' регистрируем обработчики '''
jabber.RegisterHandler('message', lambda jabber, msg: mishel.message(msg, jabber))
jabber.sendInitPresence()


@atexit.register
def destroy():
	''' на выход из программы '''
	mishel.save()
	print "disconnect"
	jabber.disconnect()
		

# https://github.com/dbader/schedule

# schedule.every(10).minutes.do(job)
# schedule.every().hour.do(job)
# schedule.every().day.at("10:30").do(job)



print "start"

# бесконечный цикл
while 1:
	schedule.run_pending()
	jabber.Process(1)

